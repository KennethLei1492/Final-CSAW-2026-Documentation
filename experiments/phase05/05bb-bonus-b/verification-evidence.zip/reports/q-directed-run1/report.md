# Phase 4 execution report

| Case | Status | Detail |
|---|---|---|
| retrigger-offset--7-1mhz | passed | 1000 samples, max error 0 |
| retrigger-offset--7-625khz | passed | 1000 samples, max error 0 |
| retrigger-offset--1-1mhz | passed | 1000 samples, max error 0 |
| retrigger-offset--1-625khz | passed | 1000 samples, max error 0 |
| retrigger-offset-0-1mhz | passed | 1000 samples, max error 0 |
| retrigger-offset-0-625khz | passed | 1000 samples, max error 0 |
| retrigger-offset-1-1mhz | passed | 1000 samples, max error 0 |
| retrigger-offset-1-625khz | passed | 1000 samples, max error 0 |
| retrigger-offset-2-1mhz | passed | 1000 samples, max error 0 |
| retrigger-offset-2-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-0-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-0-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-1-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-1-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-2-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-2-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-3-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-3-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-4-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-4-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-5-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-5-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-6-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-6-625khz | passed | 1000 samples, max error 0 |
| near-miss-word-7-1mhz | passed | 1000 samples, max error 0 |
| near-miss-word-7-625khz | passed | 1000 samples, max error 0 |
| right-slot-only-1mhz | passed | 1000 samples, max error 0 |
| right-slot-only-625khz | passed | 1000 samples, max error 0 |
| prefix-restart-1mhz | passed | 1000 samples, max error 0 |
| prefix-restart-625khz | passed | 1000 samples, max error 0 |
